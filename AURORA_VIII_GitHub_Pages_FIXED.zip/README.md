# AURORA VIII

Prototype autonome corrigé pour GitHub Pages.

Le fichier index.html contient le HTML, CSS, JavaScript et les données Aurora.

# AURORA VIII — Mobile Fixed

Version optimisée pour iPhone.

Corrections principales :
- suppression du débordement horizontal ;
- titres responsifs et lisibles ;
- boutons de navigation qui se replient correctement ;
- cartes et interactions contraintes à la largeur de l'écran ;
- hero et illustration adaptés au mobile ;
- drawer de navigation adapté aux petits écrans.

Déployer `index.html` à la racine du dépôt GitHub Pages.
